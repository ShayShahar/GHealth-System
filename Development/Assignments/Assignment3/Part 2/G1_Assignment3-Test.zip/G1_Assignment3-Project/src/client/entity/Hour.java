package client.entity;

// TODO: Auto-generated Javadoc
/**
 * Hour class defines the Specialist hour's.
 *
 * @author YAKIR
 */
public class Hour {

	/** The hour. */
	//Class Members
	private String hour;
	
	
	/**
	 * Gets the hour.
	 *
	 * @return the hour
	 */
	//Class Properties
	public String getHour() {
		return hour;
	}

	/**
	 * Sets the hour.
	 *
	 * @param hour the new hour
	 */
	public void setHour(String hour) {
		this.hour = hour;
	}
	
	
}
