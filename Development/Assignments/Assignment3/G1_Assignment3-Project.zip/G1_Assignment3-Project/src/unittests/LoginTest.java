package unittests;

import static org.junit.Assert.*;

import org.junit.Test;

// TODO: Auto-generated Javadoc
/**
 * The Class LoginTest.
 */
public class LoginTest {

	/**
	 * Test.
	 */
	@Test
	public void test() {
		fail("Not yet implemented");
	}
	
	/**
	 * Test1.
	 */
	@Test
	public void test1() {
		fail("Not yet implemented");
	}
	
	/**
	 * Test2.
	 */
	@Test
	public void test2() {
		fail("Not yet implemented");
	}
	
	/**
	 * Test3.
	 */
	@Test
	public void test3() {
		fail("Not yet implemented");
	}
	
	/**
	 * Test4.
	 */
	@Test
	public void test4() {
		fail("Not yet implemented");
	}
	
	/**
	 * Test5.
	 */
	@Test
	public void test5() {
		fail("Not yet implemented");
	}
}
